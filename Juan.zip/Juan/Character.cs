﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Juan
{

    class Character
    {
        public string name;
        public int maxEnergy;
        public int energy;
        public int HP;
        public int maxHP;
        public Ability[] abilities = new Ability[4];

        //like a function that allows us to fill a value
        public Character()
        {
            maxEnergy = 10;
            energy = maxEnergy;
            maxHP = 10;
            HP = maxHP;
            name = "ERROR 404";
            abilities = new Ability[] { new Ability(), new Ability(), new Ability(), new Ability() };
        }

        public Character(string n, int e, int hp, Ability[] ab)
        {
            maxEnergy = energy = e;
            maxHP = HP = hp;
            name = n;
            abilities = ab;
        }

        public void printAbilities()
        {
            foreach (Ability ability in abilities)
            {
                Console.WriteLine(ability.name);
                Console.WriteLine("\tCost: " + ability.cost);
                Console.WriteLine("\tDamage: " + ability.damage);
                Console.WriteLine("\tCooldown: " + ability.cooldown + " turns\n");
            }
        }
    }
}
