﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Juan
{
    class battle
    {
        //turns
        //select ability
        public battle()
        {

        }



    }
}
